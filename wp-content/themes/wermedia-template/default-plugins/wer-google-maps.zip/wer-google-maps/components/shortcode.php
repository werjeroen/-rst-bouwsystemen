<?php
function map_list($atts) {
    $atts = shortcode_atts(array( 'id' => '' ), $atts);
    if (!empty($atts['id'])) : 
      $locations = get_field('locations',$atts['id']);
      if ($locations) :
          $out = '<section class="wer__map">';
            $out .= '<div class="acf-map" data-zoom="16">';
            foreach ($locations as $marker) {
              $icon = '';
              if ($marker['icon']) :
                $icon = 'data-marker="'.$marker['icon']['url'].'"';
              elseif (get_option('maps_custom_marker')) :
                $icon = 'data-marker="'.wp_get_attachment_image_url(get_option('maps_custom_marker')).'"';
              endif;
              $out .= '<div class="marker" '.$icon.' data-lat="'.esc_attr($marker['location']['lat']).'" data-lng="'.esc_attr($marker['location']['lng']).'">';
                $out .= '<h3>'.$marker['location_name'].'</h3>';
              $out .= '</div>';
            }
            $out .='</div>';
          $out .= '</section>';
          $out .= add_google_maps_js();
      endif;
      return $out;
    else :
      return 'Geen form id ingevuld';
    endif;
}
add_shortcode('wermap', 'map_list');