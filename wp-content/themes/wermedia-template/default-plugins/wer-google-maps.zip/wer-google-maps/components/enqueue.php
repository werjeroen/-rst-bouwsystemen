<?php
function wer_maps_files() {
  wp_enqueue_script( 'wer_maps',  plugin_dir_url( __DIR__ )  . 'assets/js/wer-maps.js', array('jquery'), '', true);      
  wp_enqueue_style('wer_maps', plugin_dir_url( __DIR__ ) .'assets/styles/map.css');                       
}
add_action( 'wp_enqueue_scripts', 'wer_maps_files' );

function wer_maps_admin_css() {
  wp_enqueue_style('wer_admin', plugin_dir_url( __DIR__ ) .'assets/styles/admin.css');
  wp_enqueue_script('wer_admin', plugin_dir_url( __DIR__ ) .'assets/js/admin.js', array('jquery'));
}
add_action('admin_enqueue_scripts', 'wer_maps_admin_css');

function add_google_maps_js() {
  return '<script src="https://maps.googleapis.com/maps/api/js?key='.MAPS_API.'&callback=Function.prototype"></script>';
}

add_action( 'admin_enqueue_scripts', 'load_wp_media_files' );
function load_wp_media_files( $page ) {
  // change to the $page where you want to enqueue the script
  if( $page == 'options-general.php' ) {
    // Enqueue WordPress media scripts
    wp_enqueue_media();
    // Enqueue custom script that will interact with wp.media
    wp_enqueue_script( 'myprefix_script', plugins_url( '/js/myscript.js' , __FILE__ ), array('jquery'), '0.1' );
  }
}