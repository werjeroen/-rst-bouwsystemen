<?php 
function maps_icon( $format = 'base64' ) {
  $icon = plugin_dir_url( __DIR__ ) .'assets/img/icon.svg';
  if ($icon) :
      $svg = file_get_contents($icon);
      $icon = base64_encode($svg);

      switch ($format) :
          case 'base64';
              return 'data:image/svg+xml;base64,'.$icon.'';
              break;
          case 'svg';
              return $svg;
              break;
          default;
              return $icon;
              break;
      endswitch;
  endif;
}


function wer_create_maps_menu() {
    $icon = null;
	add_menu_page('Maps', 'Maps', 'edit_posts', 'wer-google-maps.php', '', maps_icon() );
    add_submenu_page( 'wer-google-maps.php', 'Instellingen', 'Instellingen', 'edit_posts', 'wer-google-maps.php', 'wer_maps_page' );
	add_action( 'admin_init', 'register_maps_settings' );
}
add_action('admin_menu', 'wer_create_maps_menu');

function register_maps_settings() {
    register_setting( 'wer-maps-group', 'maps_api' );
    register_setting( 'wer-maps-group', 'maps_custom_marker' );
}

function wer_maps_page() { 
  // Save attachment ID
  if ( isset( $_POST['submit'] ) && isset( $_POST['maps_custom_marker'] ) ) :
      update_option( 'maps_custom_marker', absint( $_POST['maps_custom_marker'] ) );
  endif;
  
  wp_enqueue_media();
  
?>
<div class="wrap">
    <div>
        <div style="display:flex; margin-bottom:30px; align-items:center;">
            <div class="" style="font-size: 23px;font-weight: 400;margin: 0;padding: 9px 0 4px;line-height: 1.3;">Maps instellingen</div>
        </div>
    </div>
    <h1 class="" style="display:none;">Maps instellingen</h1>
    <?php echo settings_errors(); ?>

<form method="post" action="options.php">
    <?php settings_fields( 'wer-maps-group' ); ?>
    <?php do_settings_sections( 'wer-maps-group' ); ?>
    <div class="wer_admin_wrapper">
    <div class="wer_admin_row">
      <div class="wer_admin_column content-area">
        <div class="block__content">
          <ul class="tabs">
            <li class="tab-link current" data-tab="tab-1">Base</li>
          </ul>

          <div id="tab-1" class="tab-content current">
            <div class="form-wrapper">
              <div class="form-content">
                <h4>API</h4>
                <input type="text" name="maps_api" value="<?php echo get_option('maps_api'); ?>" />
              </div>
              <div class="form-content">
                <h4>Custom marker</h4>
                <div class='image-preview-wrapper'>
                    <img id='image-preview' src='<?php echo wp_get_attachment_url( get_option( 'maps_custom_marker' ) ); ?>' style="height:auto; max-width:100px;">
                </div>
                <div style="display:flex;">
                    <input id="upload_image_button" type="button" class="button button-primary" value="<?php _e( 'Upload marker' ); ?>" />
                    <input id="reset_image" type="button" class="button button-secondary" value="<?php _e( 'Delete marker' ); ?>" />
                </div>
                <input type='hidden' name='maps_custom_marker' id='maps_custom_marker' value='<?php if (empty(get_option( 'maps_custom_marker' ))) : echo '0'; else : echo get_option( 'maps_custom_marker' ); endif; ?>'>
              </div>
            </div>
          </div>
      </div>
  </div>
  <div class="wer_admin_column submit-area">
    <div class="block__content">
      <h3 class="block__title">Publiceer</h3>
      <?php submit_button(); ?>
    </div>
  </div>
</div>	

</form>
</div>
<?php }

add_action( 'admin_footer', 'media_selector_print_scripts' );

function media_selector_print_scripts() {

	$my_saved_attachment_post_id = get_option( 'maps_custom_marker', 0 );

	?><script type='text/javascript'>

		jQuery( document ).ready( function( $ ) {

			// Uploading files
			var file_frame;
			var wp_media_post_id = wp.media.model.settings.post.id; // Store the old id
			var set_to_post_id = <?php echo $my_saved_attachment_post_id; ?>; // Set this

			jQuery('#upload_image_button').on('click', function( event ){

				event.preventDefault();

				// If the media frame already exists, reopen it.
				if ( file_frame ) {
					// Set the post ID to what we want
					file_frame.uploader.uploader.param( 'post_id', set_to_post_id );
					// Open frame
					file_frame.open();
					return;
				} else {
					// Set the wp.media post id so the uploader grabs the ID we want when initialised
					wp.media.model.settings.post.id = set_to_post_id;
				}

				// Create the media frame.
				file_frame = wp.media.frames.file_frame = wp.media({
					title: 'Select a image to upload',
					button: {
						text: 'Use this image',
					},
					multiple: false	// Set to true to allow multiple files to be selected
				});

				// When an image is selected, run a callback.
				file_frame.on( 'select', function() {
					// We set multiple to false so only get one image from the uploader
					attachment = file_frame.state().get('selection').first().toJSON();

					// Do something with attachment.id and/or attachment.url here
					$( '#image-preview' ).attr( 'src', attachment.url ).css( 'width', 'auto' );
					$( '#maps_custom_marker' ).val( attachment.id );

					// Restore the main post ID
					wp.media.model.settings.post.id = wp_media_post_id;
				});

					// Finally, open the modal
					file_frame.open();
			});

			// Restore the main ID when the add media button is pressed
			jQuery( 'a.add_media' ).on( 'click', function() {
				wp.media.model.settings.post.id = wp_media_post_id;
			});

            $('#reset_image').click(function(){
                $('#maps_custom_marker').val('0');
                $('#image-preview').hide();
            });

		});

	</script><?php

}