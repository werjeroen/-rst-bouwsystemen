<?php
/* 
    Plugin Name: We'R Media Google maps
    Description: Google maps voor op de website
    Version: 1.0
    Text Domain: wer-maps
*/

require_once( plugin_dir_path( __FILE__ ) . 'components/settings.php' );
require_once( plugin_dir_path( __FILE__ ) . 'components/cpt.php' );
require_once( plugin_dir_path( __FILE__ ) . 'components/shortcode.php' );
require_once( plugin_dir_path( __FILE__ ) . 'components/enqueue.php' );
require_once( plugin_dir_path( __FILE__ ) . 'components/meta.php' );

define('MAPS_API', get_option('maps_api'));

function acf_init_maps_api() {
    acf_update_setting('google_api_key', MAPS_API);
}
add_action('acf/init', 'acf_init_maps_api');

function extra_maps_admin_column($defaults) {
    $defaults['wer_map_shortcode'] = 'Shortcode';
    return $defaults;
}
add_filter('manage_maps_posts_columns', 'extra_maps_admin_column');
     
function extra_maps_admin_column_content($column_name, $post_ID) {
    if ($column_name == 'wer_map_shortcode') {
        echo '<code>[wermap id="'.$post_ID.'"]</code>';
    }
 }
 add_action('manage_maps_posts_custom_column', 'extra_maps_admin_column_content', 10, 2);